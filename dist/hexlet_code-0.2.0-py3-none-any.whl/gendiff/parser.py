TWO_SPACES = "  "
FOUR_SPACES = "    "

def parse_files(file1, file2):
    keys = file1.keys() | file2.keys()
    diff_string = []
    for key in sorted(keys):
        if key in file1 and key in file2:
            if file1[key] == file2[key]:
                diff_string.append('{0}{1}: {2} \n'.format(FOUR_SPACES, key, file1[key]))
            else:
                diff_string.append('{0}- {1}: {2} \n'.format(TWO_SPACES, key, file1[key]))
                diff_string.append('{0}+ {1}: {2} \n'.format(TWO_SPACES, key, file2[key]))
        elif key in file1:
            diff_string.append('{0}- {1}: {2} \n'.format(TWO_SPACES, key, file1[key]))
        elif key in file2:
            diff_string.append('{0}+ {1}: {2} \n'.format(TWO_SPACES, key, file2[key]))
    diff_string = '{{\n{}}}'.format(''.join(diff_string))
    return ''.join(diff_string)
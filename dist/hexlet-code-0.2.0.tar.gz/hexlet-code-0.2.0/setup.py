# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.scripts', 'gendiff.tests', 'gendiff.tests.fixtures']

package_data = \
{'': ['*']}

install_requires = \
['pytest-cov>=2.12.1,<3.0.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.2.0',
    'description': '',
    'long_description': None,
    'author': 'nikbyar',
    'author_email': 'nikbyar@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
